#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>


int main(int argc, char *argv[]){

	int pfd[2];		

	
	pipe(pfd);

	int pid = fork();//forking a child
	if(pid==0){
		//Child Process

		close(pfd[0]);//Close read-end of pipe
		dup2(pfd[1],1);	//taking in values from output into the pipe

		char * args[] = {"grep","-n",argv[1],argv[2],NULL};	//Executing grep
		execvp(args[0],args);										
	}
	else{
		//Parent Process
		close(pfd[1]);			//Close write-end of  pipe
		char temp[1];
		int flag = 0;			//Flag set to 0 ,baiscally separates the lines
					             
		while(read(pfd[0],temp,1) > 0){//to read characters one by one
			if(temp[0]==':') 
				flag = 1;
			else 
				if(temp[0]=='\n') 
					flag = 0;

			if(flag==0) 
			printf("%c",temp[0]);		//Print char if flag is 0
		}
		exit(0);
	}
}