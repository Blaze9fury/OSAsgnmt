#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>

int main(){

	//Input variables
	int n,k,r;
	printf("Enter n: ");
	scanf("%d",&n);
	printf("Enter k: ");
	scanf("%d",&k);

	char K[10];					 
	sprintf(K,"%d",k+1);

	printf("Enter r: ");
	scanf("%d",&r);


	int pfd[2];//
	pipe(pfd);

	int pid = fork();

	if(pid==0){
		//Child Process
		close(pfd[1]);		//Close write-end of pipe

		while(1){
			int count = r;			//Stores number of iterations already happened
			while(count>0){
				//Separator for each iteration
				printf("----------------------------------------------------------------------------------------------------------------------------\n");
				count--;
				int ch2 = fork();
				if(ch2==0){
					//Child process 
					int pfd2[2];		//Passes data from ps to head
					pipe(pfd2);
					int head = fork();

					if(head==0){
						//Child process (prints top k lines) 		
						close(pfd2[1]);
						dup2(pfd2[0],0);//Stdin from pipe2  (result of ps command execution),pipe 2 reads it

						
						char * args[] = {"head","-n",K};	//executing head command,gives the final output		
						execvp(args[0],args);	
					}
					else{
						//Parent process of head child, runs ps command 		
						close(pfd2[0]);
						dup2(pfd2[1],1);			//data is inserted in pipe to be read by  child
						char * args[] = {"ps","ax","o","\045cpu,command","--sort","-\045cpu",NULL};
						execvp(args[0],args);
					}

				}
				else{
					//Parent process of second child
					sleep(n);
				}
			}
			
			int id;
			char message[] = "\nEnter pid of process to kill (or -1 to ignore): ";
			write(1,message,sizeof(message));
			read(pfd[0],&id,sizeof(id));			//Read pid from pipe
			if(id!=-1){ kill(id,SIGINT);
				    printf("Process killed\n");
				  }
			//Kill process unless -1
		}
	}
	else{
		//Parent Process
		close(pfd[0]);
		int id;
		while(1){
               				
			scanf("%d",&id);  //endless loop to input id               
			write(pfd[1],&id,sizeof(id));		//Write PID to pipe,PID sent to child

		}
	}
}
