#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<unistd.h>
#include<time.h>
#include<stdbool.h>
#include<signal.h>
#include<string.h>
#include<sys/prctl.h>

bool isPrime(int x) {
if(x<2) 
 return false;
for(int i=2;i*i<x;i++)
 if(x%i==0)
   return false;
return true;
}

int main() {

 int fd[2];
 pid_t pid;

 //pipe(fd);
 if(pipe(fd)==-1) {
   perror("Pipe failed\n");
   return 1;
 } 

  pid = fork();

  if(pid < 0) {

    perror("fork failed\n");
    return 1;

  } else if(pid==0){ /*child process*/

    close(fd[1]); //closes write end of pipe

    int yPassed[1];
    int S=0;
    
    while(1) {
     read(fd[0], yPassed,sizeof(int));
     
     if(isPrime(yPassed[0])) {
       printf("%d is prime\n",yPassed[0]);
       (S)+=yPassed[0];
     } else 
       printf("%d is not prime\n",yPassed[0]);

      printf("S= %d\n",S);
      sleep(yPassed[0]%3);
    } 
    printf("Child exiting\n");
    exit(0);

  } else if(pid > 0) { /*parent process */
 
   close(fd[0]);//closes unused read end of pipe

   int arr[]={11,12,13,14,15,16,17,18,19,20};
   int n=10;
   bool flag[10]={false};
   srand(time(NULL)); 

   int a=10;
   while(a!=0){
    	int x,y;
    	x=arr[rand()%n];
    	y=arr[rand()%n];

     if(x!=y){
    	printf("x=%d, y=%d\n",x,y);
   	flag[x]=true;
	flag[y]=true;

        write(fd[1], &y,sizeof(y)) ;

        sleep(x/3);
     }
        a=0;
	for(int i=0;i<10;i++) {
		if(flag[i]==false) 
			a++;
         }

   }
   kill(pid,SIGKILL);
   printf("child killed\n parent exiting\n");
   exit(0);
  }
  
return 0;
}
